import profile from "../../assets/images/profile.svg";
const userData = {
  topUser: [
    {
      id: 101,
      name: "Static User 1",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 102,
      name: "Static User 2",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 103,
      name: "Static User 3",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 104,
      name: "Static User 4",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 105,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    
  ],
  spaceOwners: [
    {
      id: 101,
      name: "Static User 1",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 102,
      name: "Static User 2",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 103,
      name: "Static User 3",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 104,
      name: "Static User 4",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 105,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 106,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 107,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 108,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 109,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 110,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 111,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 112,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 113,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 114,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 115,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"space owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    
  ],
  rentalUsers: [
    {
      id: 101,
      name: "Static User 1",
      image:profile,
      join: "23 Jul 2021",
      role:"rantal owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 102,
      name: "Static User 2",
      image:profile,
      join: "23 Jul 2021",
      role:"rantal owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 103,
      name: "Static User 3",
      image:profile,
      join: "23 Jul 2021",
      role:"rantal owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 104,
      name: "Static User 4",
      image:profile,
      join: "23 Jul 2021",
      role:"rantal owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 105,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"rantal owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 106,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"rantal owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 107,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"rantal owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 108,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"rantal owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    {
      id: 109,
      name: "Static User 5",
      image:profile,
      join: "23 Jul 2021",
      role:"rantal owners", 
      phone:"(808) 6676 555",
      email:"examples@gmail.com"
    },
    
  ],
};

export default userData;
