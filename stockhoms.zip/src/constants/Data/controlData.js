const controlData = [
  {
    id: 101,
    condition: "For rental terms",
    status: true,
  },
  {
    id: 102,
    condition: "For rental terms",
    status: false,
  },
  {
    id: 103,
    condition: "For rental terms",
    status: true,
  },
  {
    id: 104,
    condition: "For rental terms",
    status: false,
  },
];

export default controlData;
