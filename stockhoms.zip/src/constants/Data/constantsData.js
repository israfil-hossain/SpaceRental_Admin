const months = [
    { label: "January", value: "january" },
    { label: "February", value: "february" },
    { label: "March", value: "march" },
    { label: "April", value: "april" },
    { label: "May", value: "may" },
    { label: "June", value: "june" },
    { label: "July", value: "july" },
    { label: "August", value: "august" },
    { label: "September", value: "september" },
    { label: "October", value: "october" },
    { label: "November", value: "november" },
    { label: "December", value: "december" },
];

const earnings =[
    {label:"Week", value:"week",}, 
    {label:"Month", value:"month",}, 
]

const commisions = [
    {label:"Space Owner", value:"space-owner",},
    {label:"Rental Owner", value:"rental-owner",},

]; 

const Status = [
    {label:"Active", value:true }, 
    {label: "Inactive", value: false }
]

const commisionPercent = [
    {label:"1 %", value:1,}, 
    {label:"2 %", value:2,}, 
    {label:"3 %", value:3,}, 
    {label:"4 %", value:4,}, 
    {label:"5 %", value:5,}, 
    {label:"6 %", value:6,}, 
    {label:"7 %", value:7,}, 
    {label:"8 %", value:8,}, 
    {label:"9 %", value:9,}, 
    {label:"10 %", value:10,}, 
    {label:"11 %", value:11,}, 
    {label:"12 %", value:12,}, 
    {label:"13 %", value:13,}, 
    {label:"14 %", value:14,}, 
    {label:"15 %", value:15,}, 
    {label:"16 %", value:16,}, 
    {label:"17 %", value:17,}, 
    {label:"18 %", value:18,}, 
    {label:"19 %", value:19,}, 
    {label:"20 %", value:20,}, 
]
export {
    months,
    earnings,
    commisions,
    commisionPercent,
    Status

}; 