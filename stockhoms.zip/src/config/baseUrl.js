// export const baseUrl = {
//     information: "http://89.116.228.42:8000/api",
//     file: "http://89.116.228.42:8000/api",
// };

export const baseUrl = {
    information: "https://mrcs-api.vercel.app/api",
};
