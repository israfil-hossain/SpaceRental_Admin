import control from "./control.svg";
import earnings from "./earnings.svg"; 
import stores from "./stores.svg"; 
import profile from "./profile_icon.svg"; 
import support from "./supports.svg";
import calender from "./Calendar.svg";
import redMoney from "./redMoney.svg"; 
import yellowMoney from "./yellowMoney.svg";
import orangeMoney from "./orangeMoney.svg";
import greenMoney from "./greenMoney.svg";
export {
    control, 
    earnings, 
    stores, 
    profile, 
    support,
    calender, 
    redMoney, 
    yellowMoney, 
    orangeMoney, 
    greenMoney,


}