import wave from "./wave.png"; 

import wave2 from "./wave2.png";
import subscribe from "./Subscriber.gif";
import Profile from "./Profile.svg";
import logo from "./Stockams.png"; 
import profile from "./images/profile.svg";

export {
    wave,
    wave2,
    subscribe,
    Profile, 
    logo,
    profile,
}