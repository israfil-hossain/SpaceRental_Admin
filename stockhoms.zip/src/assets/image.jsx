import logo from "./mrcs.png"; 
import background3 from "./background3.png"; 
import congratulation from "./images/Congratulation.png"; 
import notfound from "./images/notfound.gif"; 
import loader from "./images/loader.gif"; 

export {
    logo, 
    background3, 
    congratulation, 
    notfound, 
    loader
}

